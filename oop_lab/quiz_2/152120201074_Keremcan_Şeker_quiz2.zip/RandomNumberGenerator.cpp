//randNum = minNumber + (rand() % (maxNumber - minNumber + 1));

#include "RandomNumberGenerator.h"
#include <time.h>  
#include <iostream>  
using namespace std; 
RandomNumberGenerator::RandomNumberGenerator()  
{  
srand(time(NULL));  
}  
RandomNumberGenerator::~RandomNumberGenerator()  
{  
}  
int RandomNumberGenerator::getRandomInteger(int lowerBound, int upperBound)  
{  
    int randNum = lowerBound + (rand() % (upperBound-lowerBound+1));
    return randNum;
}  
float RandomNumberGenerator::getRandomFloat(float lowerBound, float upperBound, 
Precision precision)  
{  
    int newLower, newUpper;float randFloat;
    switch (precision)
    {
    case  ONE:
        newLower = lowerBound * 10;
        newUpper = upperBound * 10;
        randFloat = newLower + (rand()% (newUpper - newLower + 1));
        randFloat = randFloat / 10;
        return randFloat;
        break;
    case TWO:
        newLower = lowerBound * 100;
        newUpper = upperBound * 100;
        randFloat = newLower + (rand()% (newUpper - newLower + 1));
        randFloat = randFloat / 100;
        return randFloat;
    case THREE:
        newLower = lowerBound * 1000;
        newUpper = upperBound * 1000;
        randFloat = newLower + (rand()% (newUpper - newLower + 1));
        randFloat = randFloat / 1000;
        return randFloat;
    case FOUR:
        newLower = lowerBound * 10000;
        newUpper = upperBound * 10000;
        randFloat = newLower + (rand()% (newUpper - newLower + 1));
        randFloat = randFloat / 10000;
        return randFloat;
    default:
        break;
    }

// Implement the function  
// You are required to use switch case structure for the enum type  
}  
double RandomNumberGenerator::getRandomDouble(double lowerBound, double upperBound, 
Precision precision)  
{  
    int newLower, newUpper;double randDouble;
switch (precision)
    {
    case  ONE:
        newLower = lowerBound * 10;
        newUpper = upperBound * 10;
        randDouble = newLower + (rand()% (newUpper - newLower + 1));
        randDouble = randDouble / 10;
        return randDouble;
        break;
    case TWO:
        newLower = lowerBound * 100;
        newUpper = upperBound * 100;
        randDouble = newLower + (rand()% (newUpper - newLower + 1));
        randDouble= randDouble/ 100;
        return randDouble;
    case THREE:
        newLower = lowerBound * 1000;
        newUpper = upperBound * 1000;
        randDouble = newLower + (rand()% (newUpper - newLower + 1));
        randDouble= randDouble/ 1000;
        return randDouble;
    case FOUR :
        newLower = lowerBound * 10000;
        newUpper = upperBound * 10000;
        randDouble = newLower + (rand()% (newUpper - newLower + 1));
        randDouble= randDouble/ 10000;
        return randDouble;
    default:
        break;
    }
 
}
