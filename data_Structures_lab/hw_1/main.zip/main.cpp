// Group Members
// Keremcan ŞEKER 152120201074
// Esma KOÇAK 152120211058

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <math.h>
using namespace std;
ifstream file;

//calculates the number of pixel in a blob using recursion
int pixelCounter(vector<vector<char>>&, int, int); 

void printCols(int,string&);

ifstream& GotoLine(ifstream& file, unsigned int num);

string numbers;
string lines;

int r, c; // global variables for row and column 
vector<double>CoMR(r* c / 2); //center of mass row
vector<double>CoMC(r* c / 2); //center of mass column
int p, q = 0; // iterators
int main()
{
	
	double point = 0;
	int n = 0;
	string fileName;
	cout << "Please enter the filename: ";
	cin >> fileName;
	file.open(fileName);
	file >> r >> c;

	vector<vector<char>> BlobMatrix(r, vector<char>(c)); // the whole matrix contains everything spaces and x's
	vector<int> numberOfPixels(r * c / 2); //holds the number of pixel in a blob
	char x;
	int i = 0;
	BlobMatrix.resize(r);
	GotoLine(file, 2) >> noskipws >> x;
	printCols(c,lines);
	cout << "  " << lines << endl;
	while (!file.eof())
	{
		for (int i = 0; i < r; i++)
		{
			cout << " " << i << "|";
			BlobMatrix[i].resize(c);
			for (int j = 0; j < c; j++)
			{
				BlobMatrix[i][j] = x;
				if (j == c - 1)
				{
					cout << BlobMatrix[i][j] << "|" << i;
				}
				else
				{
					cout << BlobMatrix[i][j];
				}
				file >> x;

			}
			cout << endl;
			file >> x;
		}
	}
	cout << "  " << lines << endl;
	printCols(c,lines);
	cout << endl;
	int flag = 0;
	for (size_t i = 0; i < r; i++)
	{
		for (size_t j = 0; j < c; j++)
		{
			int a = pixelCounter(BlobMatrix, i, j); // calculate pixel amount in a blob
			if (a != 0)
			{
				CoMR.insert(CoMR.begin(), p);
				CoMC.insert(CoMC.begin(), q);
				numberOfPixels.insert(numberOfPixels.begin(), a);
				flag++;
				p = 0;
				q = 0;
			}
		}
	}
	CoMR.resize(flag);
	CoMC.resize(flag);
	numberOfPixels.resize(flag);
	int comr = 0, coml = 0;
	cout << "+------+------------+---------+------------+" << endl;
	cout << "| BLOB | NoOfPixels | CoM Row | CoM Column |" << endl;
	cout << "+------+------------+---------+------------+" << endl;
	int j = numberOfPixels.size();
	for (int i = 0; i < numberOfPixels.size(); i++)
	{
		int index = numberOfPixels.size() - 1;
		double size = numberOfPixels.at(index - i);
		cout << "|" << setw(6) << i + 1 << "|" << setw(12) << numberOfPixels.at(index - i) << "|"
			<< setw(9) << fixed << setprecision(2) << CoMR[index - i] / size <<
			"|" << setw(12) << CoMC[index - i] / size << "|" << endl;

	}
	cout << "+------+------------+---------+------------+" << endl;

	return 0;
}
void printCols(int c, string& lines)
{
	cout << "   ";
	int col = 0;
	int flag = 0;
	
	do
	{
		cout << col;
		col += 1;
		flag += 1;
		if (col == 10)
		{
			col = 0;
		}
	} while (flag != c);
	cout << "\n";
	for (size_t i = 0; i < c + 2; i++)
	{
		if (i == 0 || i == c + 1)
		{
			lines += "+";
		}
		else
		{
			lines += "-";
		}
	}
}
ifstream& GotoLine(ifstream& file, unsigned int num) {
	file.seekg(ios::beg);
	for (int i = 0; i < num - 1; ++i) {
		file.ignore(numeric_limits<streamsize>::max(), '\n');
	}
	return file;
}


int pixelCounter(vector<vector<char>>& CM, int row, int col)
{
	if (row < 0 || col < 0 || col >= c || row >= r)
	{
		return 0;
	}
	else if (CM[row][col] == ' ')
	{
		return 0;
	}
	else if (CM[row][col] == 'x')
	{
		CM[row][col] = 'f';// this prevents the algorithm from a bug that happens because recursion
		p += row;		   // it marks the cell that has been visited beforeç so that the algorithm won't revisit it again
		q += col;
		return 1 + pixelCounter(CM, row, col - 1) + pixelCounter(CM, row, col + 1) + pixelCounter(CM, row - 1, col) +
			pixelCounter(CM, row + 1, col);
	}
	else
	{
		return 0;
	}
}